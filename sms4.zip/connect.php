<?php

$connect = mysqli_connect ("localhost", "regi_adminregistrar" , "jbn+^wimGoxE7E!%" , "regi_bcpregistrar4");
if(mysqli_connect_errno()){
    echo "Failed to connect to mysql:", mysqli_connect_error();
}

?>



